﻿
$keyVaultName = 'KeyVaultName'

$KeyVaultRGName = 'KeyVaultResourceGroupName'

$KeyName= 'DiskEncryptionKeyName'

$VMName= 'AzureVMName'

$VMRGName = 'VMResourceGroupName'

$UPN ='YourAzureADUPN'

# Set Key Vault Access Policy to add your account (Not required if you already have access)

Set-AzKeyVaultAccessPolicy -VaultName $keyVaultName -UserPrincipalName $UPN -PermissionsToKeys create,import,delete,list -PassThru


# Set Access Policy to Enable Azure Disk Encryption for Volume Encryption (Not required if already configured)

Set-AzKeyVaultAccessPolicy -VaultName $keyVaultName -ResourceGroupName $KeyVaultRGName -EnabledForDiskEncryption

# Create New Key (Not required if you want to use an exisiting key)

Add-AzKeyVaultKey -VaultName $keyVaultName  -Name $KeyName -Destination "Software"

# Retrive Required Key Vault Paramaters and Store in Variables

$keyVault = Get-AzKeyVault -VaultName $keyVaultName -ResourceGroupName $KeyVaultRGName
$diskEncryptionKeyVaultUrl = $keyVault.VaultUri
$keyVaultResourceId = $keyVault.ResourceId
$keyEncryptionKeyUrl = (Get-AzKeyVaultKey -VaultName $keyVaultName -Name $KeyName).Key.kid

# Encrypt All Volumes of the VM

Set-AzVMDiskEncryptionExtension -ResourceGroupName $VMRGName -VMName $VMName -DiskEncryptionKeyVaultUrl $diskEncryptionKeyVaultUrl -DiskEncryptionKeyVaultId $keyVaultResourceId -KeyEncryptionKeyUrl $keyEncryptionKeyUrl -KeyEncryptionKeyVaultId $keyVaultResourceId -Force

    
    